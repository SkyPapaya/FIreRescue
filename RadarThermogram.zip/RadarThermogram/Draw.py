import EscapeRoute as er
# 把人的路线规划图，火情热力图合并输出
er.get_final_map()

